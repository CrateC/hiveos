#!/usr/bin/env bash
cd `dirname $0`

./xmrigDaemon-amd -a cryptonight-lite -o uplexa.herominers.com:10477 -u solo:UPX1cqYYxZdj7mHa3HpGRt3jGUsUrRb78HDdruPt2GG93NsS6ddF9248Fp6K2MgcWFcNp5Ke4yuuvCpcsEEndznu5YkRhkSGEY -p rx580 -k --donate-level=0 --opencl-devices=0,0,1,1,2,2,3,3,4,4,5,5 --opencl-launch=1728x16,1728x16,1728x16,1728x16,1728x16,1728x16,1728x16,1728x16,1728x16,1728x16 | tee /var/log/miner/xmrigccamd/xmrigcc-amd.log
